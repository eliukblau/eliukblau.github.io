<?php
$link = mysql_connect('trenchcoatsoft.com', 'gloader', 'dorianx')
 or die ("The database is not currently available. Please check back later (". mysql_error().")\n");
mysql_select_db('gloader') or die('Could not select database');
$errstr="";
if (isset($_REQUEST['start'])) $sa=$_REQUEST['start']; else $sa=0;
$query = "SELECT Name, Author, Description, Date, Inputwin, Imagewin, Menuwin, Blorb, Mouse  FROM modules ORDER BY Date DESC LIMIT $sa, 10";
print "<head><title>GLoader Gallery</title></head><body>\n";
print "Below, you can view and download GLoader pluggable UIs.  Click on
       image to enlarge.<br><a href=\"gltemplate.gblorb\">Download the
       interactive Gloader Gallery</a><br><a href=\"gltemplate.inf\">Download
       the GLoader Template and Gallery Source</a><br>";
print "<center><table>";
$result = mysql_query($query) or die('Query failed: ' . mysql_error());
while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
 $n=$line['Name'];
 $a=$line['Author'];
 $dd=$line['Date'];
 print "<tr><td style=\"background: #d0d0ff\"><a href=\"gallery/$n.jpg\"><img width=100 src=\"thumbnails/$n.jpg\"></td>\n";
 print "<td style=\"background: #d0d0ff; font: 11px Arial, Helvetica\"><b>$n</b> by $a\n<p>";
 print $line['Description'];
 print "</p>\n<i>Added: $dd</i><br>\n";
 print "Features:<ul>";
 if ($line['Inputwin']) print "<li>Input Window\n";
 if ($line['Imagewin']) print "<li>Image Window\n";
  if ($line['Menuwin']) print "<li>Menu Window\n";
  if ($line['Mouse']) print "<li>Uses Mouse\n";
  if ($line['Blorb']) print "<li>Includes Blorb Resources\n";
 print "</ul><a href=\"gloader/$n.zip\">Download $n</a></td></tr>";

$sss++;

}
print "<tr><td colspan=2 style=\"background: #d0d0ff; font: 11px Arial, Helvetica\" align=right>";
if ($sa > 0) {
        $sb=$sa-10; if ($sb<0) $sb=0;
        print "<a href=\"gallery.php?start=$sb\">&lt;&lt;</a>&nbsp;&nbsp;";
        }
if ($sss>=10)
 {
        $sb=$sa+10; 
        print "<a href=\"gallery.php?start=$sb\">&gt;&gt;</a>";
        }

print "</table></center>";
?>
