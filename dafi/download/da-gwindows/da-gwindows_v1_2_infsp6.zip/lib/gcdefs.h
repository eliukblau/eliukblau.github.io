! GWindows Core Definitions file

ifndef GW_GCDEFS_H;
system_file;
Constant GW_GCDEFS_H;
Include "infglk";
Replace DrawStatusLine;
Replace Banner;
endif;

