define([], function () {

    'use strict';

    return {
//>>includeStart('strict', pragmas.strict);
        locked: true
//>>includeEnd('strict');
    };
});
